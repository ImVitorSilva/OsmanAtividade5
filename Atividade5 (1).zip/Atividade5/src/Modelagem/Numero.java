// Pacote Modelagem
package Modelagem;

// Classe que define a estrutura do nó da árvore
public class Numero {
    public int data;
    public Numero left, right;

    public Numero(int item) {
        data = item;
        left = right = null;
    }
}


