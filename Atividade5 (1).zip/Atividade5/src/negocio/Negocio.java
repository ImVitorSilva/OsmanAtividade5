// Pacote Negócio
package negocio;

import Modelagem.Numero;

// Classe que define a estrutura da árvore
public class Negocio {
    public Numero root;

    // Construtor vazio
    public Negocio() {
        root = null;
    }

    // Método para percorrer a árvore em ordem (in-order traversal)
    public void inorderTraversal(Numero node) {
        if (node != null) {
            inorderTraversal(node.left);
            System.out.print(node.data + " ");
            inorderTraversal(node.right);
        }
    }

    // Método para inserir um nó na árvore
    public void insert(int key) {
        root = insertRec(root, key);
    }

    // Função recursiva para inserção de um nó na árvore
    private Numero insertRec(Numero root, int key) {
        if (root == null) {
            root = new Numero(key);
            return root;
        }

        if (key < root.data)
            root.left = insertRec(root.left, key);
        else if (key > root.data)
            root.right = insertRec(root.right, key);

        return root;
    }
}