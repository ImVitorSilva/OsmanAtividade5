// Pacote Visão
package visao;

import javax.swing.JOptionPane;
import Modelagem.Numero;
import negocio.Negocio;

// Classe que interage com o usuário
public class Main {
    public static void main(String[] args) {
        Negocio tree = new Negocio();

        // Adicionando elementos à árvore
        tree.insert(50);
        tree.insert(30);
        tree.insert(20);
        tree.insert(40);
        tree.insert(70);
        tree.insert(60);
        tree.insert(80);

        // Exibindo os elementos da árvore em ordem
        System.out.print("Árvore em ordem (in-order): ");
        tree.inorderTraversal(tree.root);
        System.out.println();

        // Utilizando JOptionPane para interagir com o usuário
        JOptionPane.showMessageDialog(null, "Árvore em ordem (in-order): " + treeInorderTraversalToString(tree.root));
    }

    // Método para percorrer a árvore em ordem e retornar uma string
    private static String treeInorderTraversalToString(Numero node) {
        if (node != null) {
            String left = treeInorderTraversalToString(node.left);
            String right = treeInorderTraversalToString(node.right);
            return left + " " + node.data + " " + right;
        }
        return "";
    }
}
